TASKS = ["easy", "medium", "hard"]
